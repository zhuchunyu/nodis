/**
* MCU SDK
*/

#define PRODUCT_ID "2213"

// 功能点上报定义
static device_func_info_t dev_upload_list[] = {
    UPLOAD_STRING("string", 0),
    UPLOAD_INT("int", 1),
    UPLOAD_FLOAT("float", 2),
    UPLOAD_ENUM("enum", 3),
    UPLOAD_ERROR("error", 4),
    UPLOAD_BOOL("bool", 5),
    UPLOAD_BINARY("binary", 6)
};

static device_cmd_handle_t dev_cmd_list[] = {
    CMD_STRING("string"),
    CMD_INT("int"),
    CMD_FLOAT("float"),
    CMD_ENUM("enum"),
    CMD_BOOL("bool"),
    CMD_BINARY("binary")
};

// 功能点上报

int32 device_string_upload(uint8 *val)
{
    return device_upload("string", TYPE_STRING, val, strlen(val));
}


int32 device_int_upload(int32 val)
{
    return device_upload("int", TYPE_INT, &val, sizeof(val));
}


int32 device_float_upload(float64 val)
{
    return device_upload("float", TYPE_FLOAT, &val, sizeof(val));
}


typedef enum
{
    enum_ENUM_0,
    enum_ENUM_1,
    enum_ENUM_2,
    enum_ENUM_3
} enum_enum_t;

int32 device_enum_upload(enum_enum_t val)
{
    return device_upload("enum", TYPE_ENUM, &val, sizeof(val));
}


typedef enum
{
    ERROR_error_0,
    ERROR_error_1,
    ERROR_error_2
} error_err_type_t;

int32 device_error_error(error_err_type_t type, bool status)
{
    device->err_code = status ? SET_BIT_64(device->err_code, type) : CLEAR_BIT_64(device->err_code, type);
    return device_upload("error", TYPE_ERROR, &(device->err_code), sizeof(device->err_code));
}


int32 device_bool_upload(bool val)
{
    return device_upload("bool", TYPE_BOOL, &val, sizeof(val));
}


int32 device_binary_upload(uint8 *val, uint16 val_len)
{
    return device_upload("binary", TYPE_BINARY, val, val_len);
}


// 功能点下发
int32 device_string_callback(uint8 *val)
{
    /** To Do*/
    return 0;
}

int32 device_int_callback(int32 val)
{
    /** To Do*/
    return 0;
}

int32 device_float_callback(float64 val)
{
    /** To Do*/
    return 0;
}

int32 device_enum_callback(enum_enum_t val)
{
    /** To Do*/
    return 0;
}

int32 device_bool_callback(bool val)
{
    /** To Do*/
    return 0;
}

int32 device_binary_callback(uint8 *val, uint16 val_len)
{
    /** To Do*/
    return 0;
}

